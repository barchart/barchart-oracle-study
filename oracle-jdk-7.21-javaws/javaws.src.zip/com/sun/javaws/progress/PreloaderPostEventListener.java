package com.sun.javaws.progress;

import com.sun.applet2.preloader.event.PreloaderEvent;

public abstract interface PreloaderPostEventListener
{
  public abstract void eventHandled(PreloaderEvent paramPreloaderEvent);
}

/* Location:           /home/user1/Temp/jvm/javaws.jar
 * Qualified Name:     com.sun.javaws.progress.PreloaderPostEventListener
 * JD-Core Version:    0.6.2
 */