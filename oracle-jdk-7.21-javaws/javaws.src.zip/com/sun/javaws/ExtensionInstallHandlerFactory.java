package com.sun.javaws;

public class ExtensionInstallHandlerFactory
{
  public static ExtensionInstallHandler newInstance()
  {
    return null;
  }
}

/* Location:           /home/user1/Temp/jvm/javaws.jar
 * Qualified Name:     com.sun.javaws.ExtensionInstallHandlerFactory
 * JD-Core Version:    0.6.2
 */