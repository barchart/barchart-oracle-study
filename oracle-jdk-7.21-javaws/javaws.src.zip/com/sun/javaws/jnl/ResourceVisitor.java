package com.sun.javaws.jnl;

public class ResourceVisitor
{
  public void visitJARDesc(JARDesc paramJARDesc)
  {
  }

  public void visitPropertyDesc(PropertyDesc paramPropertyDesc)
  {
  }

  public void visitPackageDesc(PackageDesc paramPackageDesc)
  {
  }

  public void visitExtensionDesc(ExtensionDesc paramExtensionDesc)
  {
  }

  public void visitJREDesc(JREDesc paramJREDesc)
  {
  }

  public void visitJFXDesc(JavaFXRuntimeDesc paramJavaFXRuntimeDesc)
  {
  }
}

/* Location:           /home/user1/Temp/jvm/javaws.jar
 * Qualified Name:     com.sun.javaws.jnl.ResourceVisitor
 * JD-Core Version:    0.6.2
 */