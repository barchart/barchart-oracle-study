package javax.jnlp;

public abstract interface SingleInstanceListener
{
  public abstract void newActivation(String[] paramArrayOfString);
}

/* Location:           /home/user1/Temp/jvm/javaws.jar
 * Qualified Name:     javax.jnlp.SingleInstanceListener
 * JD-Core Version:    0.6.2
 */