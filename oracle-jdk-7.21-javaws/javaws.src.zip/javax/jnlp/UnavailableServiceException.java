package javax.jnlp;

public class UnavailableServiceException extends Exception
{
  public UnavailableServiceException()
  {
  }

  public UnavailableServiceException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/javaws.jar
 * Qualified Name:     javax.jnlp.UnavailableServiceException
 * JD-Core Version:    0.6.2
 */