package javax.jnlp;

public abstract interface SingleInstanceService
{
  public abstract void addSingleInstanceListener(SingleInstanceListener paramSingleInstanceListener);

  public abstract void removeSingleInstanceListener(SingleInstanceListener paramSingleInstanceListener);
}

/* Location:           /home/user1/Temp/jvm/javaws.jar
 * Qualified Name:     javax.jnlp.SingleInstanceService
 * JD-Core Version:    0.6.2
 */