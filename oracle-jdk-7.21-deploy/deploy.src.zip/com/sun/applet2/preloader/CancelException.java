package com.sun.applet2.preloader;

import java.io.IOException;

public class CancelException extends IOException
{
  public CancelException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.applet2.preloader.CancelException
 * JD-Core Version:    0.6.2
 */