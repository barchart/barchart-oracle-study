package com.sun.applet2.preloader.event;

public class ApplicationExitEvent extends PreloaderEvent
{
  public ApplicationExitEvent()
  {
    super(8);
  }

  public String toString()
  {
    return "ApplicationExitEvent";
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.applet2.preloader.event.ApplicationExitEvent
 * JD-Core Version:    0.6.2
 */