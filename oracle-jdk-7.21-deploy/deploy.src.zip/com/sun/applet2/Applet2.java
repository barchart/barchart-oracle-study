package com.sun.applet2;

public abstract interface Applet2
{
  public abstract void init(Applet2Context paramApplet2Context);

  public abstract void start();

  public abstract void stop();

  public abstract void destroy();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.applet2.Applet2
 * JD-Core Version:    0.6.2
 */