package com.sun.deploy.ui;

public abstract interface JavaTrayIconController
{
  public abstract boolean isJavaConsoleVisible();

  public abstract void showJavaConsole(boolean paramBoolean);
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.ui.JavaTrayIconController
 * JD-Core Version:    0.6.2
 */