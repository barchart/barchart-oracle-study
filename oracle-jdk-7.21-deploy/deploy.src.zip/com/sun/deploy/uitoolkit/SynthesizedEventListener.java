package com.sun.deploy.uitoolkit;

import java.util.Map;

public abstract interface SynthesizedEventListener
{
  public abstract void synthesizeEvent(Map paramMap);

  public abstract void requestFocus();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.uitoolkit.SynthesizedEventListener
 * JD-Core Version:    0.6.2
 */