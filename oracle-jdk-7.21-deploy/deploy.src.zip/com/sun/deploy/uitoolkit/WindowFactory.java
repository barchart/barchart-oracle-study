package com.sun.deploy.uitoolkit;

public abstract class WindowFactory
{
  public abstract Window createWindow();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.uitoolkit.WindowFactory
 * JD-Core Version:    0.6.2
 */