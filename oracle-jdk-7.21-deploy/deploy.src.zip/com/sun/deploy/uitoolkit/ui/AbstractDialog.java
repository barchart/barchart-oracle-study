package com.sun.deploy.uitoolkit.ui;

public abstract class AbstractDialog
{
  public abstract void toFront();

  public abstract void requestFocus();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.uitoolkit.ui.AbstractDialog
 * JD-Core Version:    0.6.2
 */