package com.sun.deploy.uitoolkit.ui;

public abstract interface ComponentRef
{
  public abstract Object get();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.uitoolkit.ui.ComponentRef
 * JD-Core Version:    0.6.2
 */