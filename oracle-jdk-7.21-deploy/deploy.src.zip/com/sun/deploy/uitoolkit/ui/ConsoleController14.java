package com.sun.deploy.uitoolkit.ui;

import java.util.logging.Logger;

public abstract interface ConsoleController14 extends ConsoleController
{
  public abstract void setLogger(Logger paramLogger);

  public abstract Logger getLogger();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.uitoolkit.ui.ConsoleController14
 * JD-Core Version:    0.6.2
 */