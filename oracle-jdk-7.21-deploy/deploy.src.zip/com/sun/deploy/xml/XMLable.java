package com.sun.deploy.xml;

public abstract interface XMLable
{
  public abstract XMLNode asXML();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.xml.XMLable
 * JD-Core Version:    0.6.2
 */