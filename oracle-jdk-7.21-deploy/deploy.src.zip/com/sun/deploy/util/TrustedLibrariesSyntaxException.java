package com.sun.deploy.util;

class TrustedLibrariesSyntaxException extends RuntimeException
{
  TrustedLibrariesSyntaxException(Exception paramException)
  {
    super(paramException);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.util.TrustedLibrariesSyntaxException
 * JD-Core Version:    0.6.2
 */