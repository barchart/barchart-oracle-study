package com.sun.deploy.util;

public abstract class Waiter
{
  public static final Waiter SYNC_ALWAYS = new Waiter()
  {
    protected Object wait(Waiter.WaiterTask paramAnonymousWaiterTask)
      throws Exception
    {
      return paramAnonymousWaiterTask.run();
    }
  };
  private static Waiter default_waiter = SYNC_ALWAYS;

  protected abstract Object wait(WaiterTask paramWaiterTask)
    throws Exception;

  public static synchronized void set(Waiter paramWaiter)
  {
    default_waiter = paramWaiter;
  }

  public static synchronized Waiter get()
  {
    return default_waiter;
  }

  public static Object runAndWait(WaiterTask paramWaiterTask)
    throws Exception
  {
    return get().wait(paramWaiterTask);
  }

  public static abstract interface WaiterTask
  {
    public abstract Object run()
      throws Exception;
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.util.Waiter
 * JD-Core Version:    0.6.2
 */