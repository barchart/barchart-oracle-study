package com.sun.deploy.util;

public abstract interface DeploySysAction
{
  public abstract Object execute()
    throws Exception;
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.util.DeploySysAction
 * JD-Core Version:    0.6.2
 */