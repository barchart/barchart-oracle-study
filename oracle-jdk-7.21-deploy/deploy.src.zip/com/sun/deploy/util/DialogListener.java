package com.sun.deploy.util;

public abstract interface DialogListener
{
  public abstract void beforeShow();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.util.DialogListener
 * JD-Core Version:    0.6.2
 */