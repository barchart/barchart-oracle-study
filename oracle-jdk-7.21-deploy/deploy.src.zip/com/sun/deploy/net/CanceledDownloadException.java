package com.sun.deploy.net;

public class CanceledDownloadException extends Exception
{
  CanceledDownloadException()
  {
    super("cancled download");
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.net.CanceledDownloadException
 * JD-Core Version:    0.6.2
 */