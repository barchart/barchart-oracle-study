package com.sun.deploy.net.cookie;

public class CookieUnavailableException extends Exception
{
  public CookieUnavailableException()
  {
  }

  public CookieUnavailableException(String paramString)
  {
    super(paramString);
  }

  public CookieUnavailableException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.net.cookie.CookieUnavailableException
 * JD-Core Version:    0.6.2
 */