package com.sun.deploy.net.proxy;

public class ProxyUnavailableException extends Exception
{
  public ProxyUnavailableException()
  {
  }

  public ProxyUnavailableException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.net.proxy.ProxyUnavailableException
 * JD-Core Version:    0.6.2
 */