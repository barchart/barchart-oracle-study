package com.sun.deploy.net.proxy;

public abstract interface ProxyType
{
  public static final int UNKNOWN = -1;
  public static final int NONE = 0;
  public static final int MANUAL = 1;
  public static final int AUTO = 2;
  public static final int BROWSER = 3;
  public static final int SYSTEM = 4;
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.net.proxy.ProxyType
 * JD-Core Version:    0.6.2
 */