package com.sun.deploy.panel;

import javax.swing.JPanel;

public class UnixUpdatePanelImpl
  implements UpdatePanelImpl
{
  public JPanel getPanel()
  {
    return null;
  }

  public void saveSettings()
  {
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.panel.UnixUpdatePanelImpl
 * JD-Core Version:    0.6.2
 */