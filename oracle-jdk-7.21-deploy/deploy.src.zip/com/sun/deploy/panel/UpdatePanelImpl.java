package com.sun.deploy.panel;

import javax.swing.JPanel;

public abstract interface UpdatePanelImpl
{
  public abstract JPanel getPanel();

  public abstract void saveSettings();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.panel.UpdatePanelImpl
 * JD-Core Version:    0.6.2
 */