package com.sun.deploy.association;

public class AssociationException extends Exception
{
  public AssociationException()
  {
  }

  public AssociationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.association.AssociationException
 * JD-Core Version:    0.6.2
 */