package com.sun.deploy.association;

public class AssociationNotRegisteredException extends AssociationException
{
  public AssociationNotRegisteredException()
  {
  }

  public AssociationNotRegisteredException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.association.AssociationNotRegisteredException
 * JD-Core Version:    0.6.2
 */