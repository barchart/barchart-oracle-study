package com.sun.deploy.association.utility;

public abstract interface AppConstants
{
  public static final int USER_LEVEL = 1;
  public static final int SYSTEM_LEVEL = 2;
  public static final int DEFAULT_LEVEL = 3;
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.association.utility.AppConstants
 * JD-Core Version:    0.6.2
 */