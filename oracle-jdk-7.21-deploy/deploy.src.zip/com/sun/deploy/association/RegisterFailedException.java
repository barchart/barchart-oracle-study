package com.sun.deploy.association;

public class RegisterFailedException extends AssociationException
{
  public RegisterFailedException()
  {
  }

  public RegisterFailedException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.association.RegisterFailedException
 * JD-Core Version:    0.6.2
 */