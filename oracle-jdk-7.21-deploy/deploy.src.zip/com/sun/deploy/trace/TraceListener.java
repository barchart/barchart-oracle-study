package com.sun.deploy.trace;

public abstract interface TraceListener
{
  public abstract void print(String paramString);

  public abstract void flush();
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.trace.TraceListener
 * JD-Core Version:    0.6.2
 */