package com.sun.deploy.security;

import java.security.cert.CertificateException;

public final class CertificateConfigException extends CertificateException
{
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.security.CertificateConfigException
 * JD-Core Version:    0.6.2
 */