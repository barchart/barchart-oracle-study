package com.sun.deploy.security;

class CertificateStatus
{
  public static final int EXPIRED = -1;
  public static final int VALID = 0;
  public static final int NOT_YET_VALID = 1;
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.security.CertificateStatus
 * JD-Core Version:    0.6.2
 */