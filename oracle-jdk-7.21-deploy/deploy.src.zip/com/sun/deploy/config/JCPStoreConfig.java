package com.sun.deploy.config;

public class JCPStoreConfig extends JCPConfig
{
  public JCPStoreConfig()
  {
    super(null);
  }

  public void getInternalPropValues()
  {
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.config.JCPStoreConfig
 * JD-Core Version:    0.6.2
 */