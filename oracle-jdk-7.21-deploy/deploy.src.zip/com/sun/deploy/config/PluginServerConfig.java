package com.sun.deploy.config;

public class PluginServerConfig extends ClientConfig
{
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.sun.deploy.config.PluginServerConfig
 * JD-Core Version:    0.6.2
 */