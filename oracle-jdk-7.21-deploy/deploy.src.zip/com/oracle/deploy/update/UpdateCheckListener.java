package com.oracle.deploy.update;

public abstract interface UpdateCheckListener
{
  public abstract void updateCheckStateChanged(int paramInt);
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.oracle.deploy.update.UpdateCheckListener
 * JD-Core Version:    0.6.2
 */