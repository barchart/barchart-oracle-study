package com.oracle.deploy.update;

public class UpdateCheckFactory
{
  public static UpdateCheck getInstance()
  {
    return null;
  }
}

/* Location:           /home/user1/Temp/jvm/deploy.jar
 * Qualified Name:     com.oracle.deploy.update.UpdateCheckFactory
 * JD-Core Version:    0.6.2
 */