package com.sun.deploy.uitoolkit.ui;

public abstract class PluginUIFactory extends UIFactory
{
  public abstract ModalityHelper getModalityHelper();
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     com.sun.deploy.uitoolkit.ui.PluginUIFactory
 * JD-Core Version:    0.6.2
 */