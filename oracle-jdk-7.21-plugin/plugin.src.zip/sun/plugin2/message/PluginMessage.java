package sun.plugin2.message;

public abstract class PluginMessage extends Message
{
  public PluginMessage(int paramInt, Conversation paramConversation)
  {
    super(paramInt, paramConversation);
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin2.message.PluginMessage
 * JD-Core Version:    0.6.2
 */