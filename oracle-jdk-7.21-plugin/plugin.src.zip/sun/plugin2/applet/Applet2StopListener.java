package sun.plugin2.applet;

public abstract interface Applet2StopListener
{
  public abstract void stopFailed();
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin2.applet.Applet2StopListener
 * JD-Core Version:    0.6.2
 */