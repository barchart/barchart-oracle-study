package sun.plugin2.util;

public final class BrowserType
{
  public static final int DEFAULT = 1;
  public static final int INTERNET_EXPLORER = 2;
  public static final int MOZILLA = 3;
  public static final int SAFARI_MACOSX = 4;
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin2.util.BrowserType
 * JD-Core Version:    0.6.2
 */