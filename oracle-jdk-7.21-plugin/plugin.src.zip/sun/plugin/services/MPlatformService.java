package sun.plugin.services;

public final class MPlatformService extends PlatformService
{
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.services.MPlatformService
 * JD-Core Version:    0.6.2
 */