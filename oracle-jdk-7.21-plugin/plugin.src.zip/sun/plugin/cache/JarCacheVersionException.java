package sun.plugin.cache;

public class JarCacheVersionException extends Exception
{
  JarCacheVersionException()
  {
  }

  JarCacheVersionException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.cache.JarCacheVersionException
 * JD-Core Version:    0.6.2
 */