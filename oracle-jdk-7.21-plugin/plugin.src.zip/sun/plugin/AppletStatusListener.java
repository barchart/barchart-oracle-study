package sun.plugin;

public abstract interface AppletStatusListener
{
  public abstract void statusChanged(int paramInt);
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.AppletStatusListener
 * JD-Core Version:    0.6.2
 */