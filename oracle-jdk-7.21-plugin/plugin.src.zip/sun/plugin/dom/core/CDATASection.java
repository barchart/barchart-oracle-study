package sun.plugin.dom.core;

import org.w3c.dom.Document;
import sun.plugin.dom.DOMObject;

public class CDATASection extends Text
{
  public CDATASection(DOMObject paramDOMObject, Document paramDocument)
  {
    super(paramDOMObject, paramDocument);
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.dom.core.CDATASection
 * JD-Core Version:    0.6.2
 */