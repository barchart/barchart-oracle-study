package sun.plugin.dom.css;

import org.w3c.dom.Document;
import sun.plugin.dom.DOMObject;

public final class CSSUnknownRule extends CSSRule
  implements org.w3c.dom.css.CSSUnknownRule
{
  public CSSUnknownRule(DOMObject paramDOMObject, Document paramDocument)
  {
    super(paramDOMObject, paramDocument);
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.dom.css.CSSUnknownRule
 * JD-Core Version:    0.6.2
 */