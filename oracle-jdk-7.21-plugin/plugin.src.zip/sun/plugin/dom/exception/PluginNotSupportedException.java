package sun.plugin.dom.exception;

import org.w3c.dom.DOMException;

public class PluginNotSupportedException extends DOMException
{
  public PluginNotSupportedException(String paramString)
  {
    super((short)9, paramString);
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.dom.exception.PluginNotSupportedException
 * JD-Core Version:    0.6.2
 */