package sun.plugin.liveconnect;

import java.security.BasicPermission;

public final class JavaScriptPermission extends BasicPermission
{
  public JavaScriptPermission(String paramString)
  {
    super(paramString);
  }

  public JavaScriptPermission(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.liveconnect.JavaScriptPermission
 * JD-Core Version:    0.6.2
 */