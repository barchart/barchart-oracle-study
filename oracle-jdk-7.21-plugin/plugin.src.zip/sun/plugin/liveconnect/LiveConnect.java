package sun.plugin.liveconnect;

public abstract interface LiveConnect
{
  public static final String AllJavaPermission = "AllJavaPermission";
  public static final String AllJavaScriptPermission = "AllJavaScriptPermission";
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     sun.plugin.liveconnect.LiveConnect
 * JD-Core Version:    0.6.2
 */