package netscape.security;

public class UserDialogHelper
{
  public static final String targetRiskLow()
  {
    return "Risk Low";
  }

  public static final String targetRiskColorLow()
  {
    return "#0000FF";
  }

  public static final String targetRiskMedium()
  {
    return "Risk Medium";
  }

  public static final String targetRiskColorMedium()
  {
    return "#00FF00";
  }

  public static final String targetRiskHigh()
  {
    return "Risk High";
  }

  public static final String targetRiskColorHigh()
  {
    return "#FF0000";
  }
}

/* Location:           /home/user1/Temp/jvm/plugin.jar
 * Qualified Name:     netscape.security.UserDialogHelper
 * JD-Core Version:    0.6.2
 */